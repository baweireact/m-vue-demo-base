import bar from './bar';
console.log('1')
bar();
