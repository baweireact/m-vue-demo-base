import Vue from 'vue'
import Index from './Index.vue'

new Vue({
  render: h => h(Index),
}).$mount('#app')
