import Vue from 'vue'
import Index from './pages/Index.vue'
import './index.css'

new Vue({
  render: h => h(Index)
}).$mount('#app')