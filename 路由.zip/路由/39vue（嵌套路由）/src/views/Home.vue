<template>
  <div>
    <div>
      <router-link to="/home/index" class="m-nav-item">首页</router-link>
      <router-link to="/home/me" class="m-nav-item">我的</router-link>
      <router-view></router-view>
    </div>
  </div>
</template>

<script>

export default {

}
</script>
