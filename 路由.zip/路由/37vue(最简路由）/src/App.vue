<template>
  <div id="app">
    <div id="nav">
      <router-link to="/home" class="m-nav-item">Home</router-link>
      <router-link to="/about" class="m-nav-item">About</router-link>
    </div>
    <router-view/>
  </div>
</template>
