<template>
  <div class="m-footer">
    Footer
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>