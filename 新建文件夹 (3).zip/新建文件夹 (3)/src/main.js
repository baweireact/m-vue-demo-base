import Vue from 'vue'
import Index from './pages/Index.vue'

new Vue({
  render: h =>h(Index)
}).$mount('#app')