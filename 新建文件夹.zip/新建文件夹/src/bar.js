export default function bar() {
  console.log('hello world!123')
}
