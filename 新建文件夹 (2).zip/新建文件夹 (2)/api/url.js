export const login = '/login';
export const captcha = '/captcha'
export const register = '/register'
export const forgotPassword = '/forgot_password'
export const resetPassword = '/reset_password'
export const getList = '/getlist'
export const deleteItem = '/deleteItem'
export const addItem = '/addItem'


